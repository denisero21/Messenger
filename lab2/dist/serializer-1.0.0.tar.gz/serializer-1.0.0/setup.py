from setuptools import setup
import setuptools

setup(
    name="serializer",
    packages=setuptools.find_packages(),
    version="1.0.0",
    author="Eroschenko",
    author_email='deniserochenko@gmail.com',
    url='https://github.com/denisero21/ISP-2022-053503',
    #scripts=["serializer/serializer.py", "main.py", "tests.py"]
    scripts=["main.py"]
)
